const { google } = require("googleapis");
const { Storage } = require("@google-cloud/storage");
const fs = require("fs");
const path = require("path");

const storage = new Storage();
const drive = google.drive("v3");

exports.transferFile = async (req, res) => {
  try {
    const fileId = req.query.fileId;
    if (!fileId) {
      return res.status(400).send("Missing fileId parameter.");
    }

    const auth = new google.auth.GoogleAuth({
      scopes: ["https://www.googleapis.com/auth/drive.readonly"],
    });

    const driveAuth = await auth.getClient();

    const fileMetadata = await drive.files.get({
      auth: driveAuth,
      fileId: fileId,
      fields: "name, mimeType",
    });

    const fileName = fileMetadata.data.name;
    const tempFilePath = path.join("/tmp", fileName);

    const dest = fs.createWriteStream(tempFilePath);
    await drive.files.get(
      { auth: driveAuth, fileId: fileId, alt: "media" },
      { responseType: "stream" },
      (err, res) => {
        if (err) {
          console.error("Error downloading file:", err);
          return;
        }
        res.data
          .on("end", async () => {
            console.log(`Downloaded ${fileName}`);

            // Upload to GCS
            await storage.bucket(process.env.BUCKET_NAME).upload(tempFilePath, {
              destination: fileName,
            });

            console.log(`Uploaded ${fileName} to GCS`);
          })
          .pipe(dest);
      }
    );

    res.status(200).send(`Started transfer of file: ${fileName}`);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send("Error transferring file.");
  }
};
